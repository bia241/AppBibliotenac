/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import beans.Exemplares;
import beans.Geral;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Bia
 */
public class ExemplaresDAO {
    
    private Conexao conexao;
    private Connection conn;
    
    public ExemplaresDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();    
    }
    
    public void inserir(Exemplares exemplares){
        String sql = "INSERT INTO exemplares(id_livro, status) VALUES "
                + "(?, ?)";
        try{
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setString(1, exemplares.getId_livro());
        stmt.setString(2, exemplares.getStatus());
        stmt.execute();
    }
        catch(Exception e){
            System.out.println("Erro ao inserir exemplar: " + e.getMessage());
        }
    }
    
    public void editar(Exemplares exemplares){
        String sql = "UPDATE exemplares SET id_livro=?, status=? WHERE id=?";
        try{
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setString(1, exemplares.getId_livro());
        stmt.setString(2, exemplares.getStatus());
        stmt.setInt(3, exemplares.getId_exemplar());
        stmt.execute();    
        } catch (Exception e){
            System.out.println("Erro ao editar exemplar: " + e.getMessage());
        }
    }
    
    public void excluir(int id_exemplar){
        String sql = "DELETE FROM exemplares WHERE id_exemplar=?";
        try{
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setInt(1, id_exemplar);
        stmt.execute();    
        } catch (Exception e){
            System.out.println("Erro ao excluir exemplar: " + e.getMessage());
        }
    }
    
    public Exemplares getExemplares(int id_exemplar){
        String sql = "SELECT * FROM exemplares WHERE id_exemplar = ?";
        try{
            PreparedStatement stmt = this.conn.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,
            ResultSet.CONCUR_UPDATABLE);
            stmt.setInt(1, id_exemplar);
            ResultSet rs = stmt.executeQuery();
            Exemplares exemplares = new Exemplares();
            rs.first();
            exemplares.setId_exemplar(id_exemplar);
            exemplares.setId_livro(rs.getString("id_livro"));
            exemplares.setStatus(rs.getString("status"));
            return exemplares;
        } catch(Exception e){
            return null;
            
        }
    }
    
    public List<Exemplares> getExemplares(){
        
        try{
            
            List<Exemplares> listaExemplares =new ArrayList<>();
            String sql = """
                         SELECT exemplares.id_exemplar, geral.titulo, exemplares.status 
                         FROM EXEMPLARES JOIN GERAL on (exemplares.id_livro = geral.titulo)""";
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()){
                Exemplares exemplares = new Exemplares();
                Geral geral = new Geral();
                geral.setTitulo(rs.getString("titulo"));
                
                exemplares.setId_exemplar(rs.getInt("id_exemplar"));
                
                exemplares.setStatus(rs.getString("status"));
                
                exemplares.setGeral(geral);
                
                listaExemplares.add(exemplares);
            }
            return listaExemplares;
        }catch(Exception e){
            return null;
        }
    }
    }


