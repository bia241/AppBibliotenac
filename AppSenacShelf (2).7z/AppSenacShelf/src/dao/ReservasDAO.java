/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import beans.Exemplares;
import beans.Pessoa;
import beans.Reservas;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Bia
 */
public class ReservasDAO {
    private Conexao conexao;
    private Connection conn;
    
    public ReservasDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();    
    }
        public void inserir(Reservas reservas){
        String sql = "INSERT INTO reservas(id_exemplar, id_pessoa, data_reserva, status_reserva) VALUES "
                + "(?, ?, ?)";
        try{
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setInt(1, reservas.getId_exemplar());
        stmt.setInt(2, reservas.getId_pessoa());
        stmt.setInt(3, reservas.getData_reserva());
        stmt.setString(4, reservas.getStatus_reserva());
        stmt.execute();
    }
        catch(Exception e){
            System.out.println("Erro ao inserir reserva: " + e.getMessage());
        }
        }
        public void editar(Reservas reservas){
        String sql = "UPDATE reservas SET id_exemplar=?, id_pessoa=?, data_reserva=?, status_reserva=? WHERE id_reserva=?";
        try{
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setInt(1, reservas.getId_exemplar());
        stmt.setInt(2, reservas.getId_pessoa());
        stmt.setInt(3, reservas.getData_reserva());
        stmt.setString(4, reservas.getStatus_reserva());
        stmt.execute();    
        } catch (Exception e){
            System.out.println("Erro ao editar reserva: " + e.getMessage());
        }
    }
    
    public void excluir(int id_reserva){
        String sql = "DELETE FROM reservas WHERE id_reserva=?";
        try{
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setInt(1, id_reserva);
        stmt.execute();    
        } catch (Exception e){
            System.out.println("Erro ao excluir reserva: " + e.getMessage());
        }
    }
    
        public Reservas getReservas(int id_reservas){
        String sql = "SELECT * FROM reserva WHERE id_reserva = ?";
        try{
            PreparedStatement stmt = this.conn.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,
            ResultSet.CONCUR_UPDATABLE);
            stmt.setInt(1, id_reservas);
            ResultSet rs = stmt.executeQuery();
            Reservas reservas = new Reservas();
            rs.first();
            reservas.setId_reservas(id_reservas);
            
            Exemplares id_exemplar = new Exemplares();
            id_exemplar.setId_exemplar(rs.getInt("id_exemplar"));
            reservas.setId_exemplar(id_exemplar);
            
            Pessoa id_pessoa = new Pessoa();
            id_pessoa.setId_pessoa(rs.getInt("id_pessoa"));
            reservas.setId_pessoa(id_pessoa);
            
            reservas.setData_reserva(rs.getInt("data_reserva"));
            
            Exemplares status = new Exemplares();
            status.setStatus(rs.getString("status"));
            reservas.setStatus_reserva(status);
            
            return reservas;
        } catch(Exception e){
            System.out.println(e.getMessage());
            return null;
            
        }
    }
      
        public List<Reservas> getReservas(){
        String sql = "SELECT * FROM reservas";
        try{
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            List<Reservas> listaReservas = new ArrayList<>();
            while(rs.next()){
                Reservas reservas = new Reservas();
                Exemplares id_exemplar = new Exemplares();
                id_exemplar.setId_exemplar(rs.getInt("id_exemplar"));
                reservas.setId_exemplar(id_exemplar);
            
                Pessoa id_pessoa = new Pessoa();
                id_pessoa.setId_pessoa(rs.getInt("id_pessoa"));
                reservas.setId_pessoa(id_pessoa);
            
                reservas.setData_reserva(rs.getInt("data_reserva"));
            
                Exemplares status = new Exemplares();
                status.setStatus(rs.getString("status"));
                reservas.setStatus_reserva(status);
                listaReservas.add(reservas);
            }
            return listaReservas;
        }catch(Exception e){
            System.out.println(e.getMessage());
            return null;
        }
    }
    }
     
        



