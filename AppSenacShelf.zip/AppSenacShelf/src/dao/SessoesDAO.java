/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import beans.Sessoes;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Bia
 */
public class SessoesDAO {
    private Conexao conexao;
    private Connection conn;
    
    public SessoesDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();    
    }
    
    public void inserir(Sessoes sessoes){
        String sql = "INSERT INTO sessoes(genero, categoria) VALUES "
                + "(?, ?)";
        try{
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setString(1, sessoes.getGenero());
        stmt.setString(2, sessoes.getCategoria());
        stmt.execute();
    }
        catch(Exception e){
            System.out.println("Erro ao inserir curso: " + e.getMessage());
        }
    }
    
    public void editar(Sessoes sessoes){
        String sql = "UPDATE sessoes SET categoria=?, genero=? WHERE id=?";
        try{
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setString(2, sessoes.getGenero());
        stmt.setString(1, sessoes.getCategoria());
        stmt.setInt(3, sessoes.getId());
        stmt.execute();    
        } catch (Exception e){
            System.out.println("Erro ao editar categoria: " + e.getMessage());
        }
    }
    
    public void excluir(int id){
        String sql = "DELETE FROM sessoes WHERE id=?";
        try{
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setInt(1, id);
        stmt.execute();    
        } catch (Exception e){
            System.out.println("Erro ao excluir categoria: " + e.getMessage());
        }
    }
    
    public Sessoes getSessoes(int id){
        String sql = "SELECT * FROM sessoes WHERE id = ?";
        try{
            PreparedStatement stmt = this.conn.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,
            ResultSet.CONCUR_UPDATABLE);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            Sessoes sessoes = new Sessoes();
            rs.first();
            sessoes.setId(id);
            sessoes.setGenero(rs.getString("genero"));
            sessoes.setCategoria(rs.getString("categoria"));
            return sessoes;
        } catch(Exception e){
            return null;
            
        }
    }
    
    public List<Sessoes> getSessoes(String categoria){
        String sql = "SELECT * FROM sessoes WHERE categoria LIKE?";
        try{
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, "%" + categoria + "%");
            ResultSet rs = stmt.executeQuery();
            List<Sessoes> listaSessoes =new ArrayList<>();
            while(rs.next()){
                Sessoes sessoes = new Sessoes();
                sessoes.setId(rs.getInt("id"));
                sessoes.setGenero(rs.getString("genero"));
                sessoes.setCategoria(rs.getString("categoria"));
                listaSessoes.add(sessoes);
            }
            return listaSessoes;
        }catch(Exception e){
            return null;
        }
    }
}
