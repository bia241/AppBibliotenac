/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

/**
 *
 * @author Bia
 */
public class Reservas {
    private int id_reservas;
    private int id_exemplar;
    private int id_pessoa;
    private int data_reserva;
    private String status_reserva;

    public int getId_reservas() {
        return id_reservas;
    }

    public void setId_reservas(int id_reservas) {
        this.id_reservas = id_reservas;
    }

    public int getId_exemplar() {
        return id_exemplar;
    }

    public void setId_exemplar(Exemplares id_exemplar) {
        this.id_exemplar = id_exemplar;
    }

    public int getId_pessoa() {
        return id_pessoa;
    }

    public void setId_pessoa(Pessoa id_pessoa) {
        this.id_pessoa = id_pessoa;
    }

    public int getData_reserva() {
        return data_reserva;
    }

    public void setData_reserva(int data_reserva) {
        this.data_reserva = data_reserva;
    }

    public String getStatus_reserva() {
        return status_reserva;
    }

    public void setStatus_reserva(Exemplares status_reserva) {
        this.status_reserva = status_reserva;
    }

    
}
