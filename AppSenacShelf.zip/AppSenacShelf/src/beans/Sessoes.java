/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

/**
 *
 * @author Bia
 */
public class Sessoes {
    private int id;
    private String genero;
    private String categoria;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }
    
    public String toString(){
        return this.categoria;
    }

  /** public boolean equals(Object objeto){
       Sessoes s = (Sessoes) objeto;
        if(this.id == s.getId()){
            return true;
        }
        else{
            return false;
        }
    }**/
}
